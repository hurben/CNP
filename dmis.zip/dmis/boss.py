"""
.. module:: dmis.boss
    :platform: Unix, linux, Windows
.. moduleauthor:: Sunwon Lee <sun2208@gmail.com>

==================================
Biomedical entity query API
==================================

.. note:: Usage: Biomedical entity query API

>>> from dmis import boss
>>> 
>>> bossQuery = boss.BOSSQuery({"keywordA":["cancer"], "keywordB":["BRCA1", "EGFR"], "topN":30})
>>> bossQuery.addKeywordtoB("TP53")
>>> relevantEntities = boss.getRelevantBioEntities(bossQuery)
>>> 
>>> print(relevantEntities)
{'diseases': [{'abstracts': ['A distinctive feature ...',
                             'The excess risk of ...',
                             'Many important ...'],
               'entityName': 'breast neoplasms',
               'numArticles': 147184,
               'rank': 1,
               'score': 327993.0},
              {'abstracts': ["The relationship ...",
                             'Relatively little ...',
                             'Strong inter- and ...'],
               'entityName': 'ovarian neoplasms',
               'numArticles': 5526,
               'rank': 2,
               'score': 13530.978},
...

"""

from functools import reduce
import urllib

class BOSSQuery():
    """
    dmis.BOSSQuery class is basic query object for BOSS API.
    
    """
    
    bossurl = "http://best.korea.ac.kr/s?"
    
    def __init__(self, queryObj={"keywordA":"", "keywordB":[], "topN":20}):
        """BOSSQuery
        :param queryObj: keywordA (list), keywordB (list), topN (int) dict return.
        
        >>> query = BOSSQuery({"keywordA":["cancer"], "keywordB":["human breast", "BRCA1"], "topN":30})
        """
        
        if queryObj["keywordA"] == None:
            queryObj["keywordA"] = [""]
        
        if len(queryObj["keywordA"]) == 0:
            queryObj["keywordA"] = [""]
        
        if (type(queryObj["keywordA"]) is not list) or ("keywordB" not in queryObj) or (type(queryObj["keywordB"]) is not list) or ("topN" not in queryObj):
            print ("Initialize error : invalid query object, query object should contains 'keywordA (list of string)', 'keywordB (list of string)', 'topN (integer)'")
            print (queryObj)

        for keya in queryObj["keywordA"] :
            if type(keya) is not str :
                print ("Initialize error : invalid keywordA. keywordA should be either None, empty list or list of string")
                print (queryObj["keywordA"])

        for keyb in queryObj["keywordB"] :
            if type(keyb) is not str :
                print ("Initialize error : invalid keywordB. keywordB should be list of string")
                print (queryObj["keywordB"])
        
        self.keywordA = queryObj["keywordA"]
        self.keywordB = queryObj["keywordB"]
        self.topN = queryObj["topN"]
    
    def setKeywordA (self, keywords):
        """Setting the primary keywords (Keyword A)
        
        :param keyword: primary keywords, which must be a list of str
        
        >>> query.setKeywordA(["cancer"])
        """
        if type(keywords) is not list:
            print ("Initialize error : invalid keywordA. keywordA should be list of string")
            print (keywords)
            return
        
        if len(keywords) == 0:
            keywords = [""]
            return
        
        for keya in keywords :
            if type(keya) is not str :
                print ("Initialize error : invalid keywordA. keywordA should be list of string")
                print (keywords)
                return
            
        self.keywordA = keywords
        
    def getKeywordA (self):
        """Getting the primary keyword (Keyword A)
        
        :return: keyword A string
        
        >>> keywordA = query.getKeywordA()
        >>> print (keywordA)
        ["cancer"]
        """
        return self.keywordA
    
    def addKeywordtoA (self, keyword):
        """Adding a keyword to the primary keyword list (Keyword A)
        
        :param keyword: the keyword to be added to the primary keyword list
        
        >>> print (query.getKeywordA())
        ["cancer"]
        >>> query.addKeywordtoA("EGFR")
        >>> print (query.getKeywordA())
        ["cancer","EGFR"]
        """
        self.keywordB.append(keyword)
    
    def removeKeywordfromA(self, keyword):
        """Removing a keyword from the primary keyword list (Keyword A)
        
        :param keyword: the keyword to be removed from the primary keyword list
        
        >>> print (query.getKeywordA())
        ["cancer","EGFR"]
        >>> query.removeKeywordfromA("EGFR")
        >>> print (query.getKeywordA())
        ["cancer"]
        """
        self.keywordB.remove(keyword)
    
    def setKeywordB (self, keywords):
        """Setting the secondary keywords (Keyword B)
        
        :param keywords: the secondary keywords, which must be a list of str
        
        >>> keywordB = ["breast cancer","BRCA1"]
        >>> query.setKeywordB(keywordB)
        """
        
        if type(keywords) is not list:
            print ("Initialize error : invalid keywordB. keywordB should be list of string")
            print (keywords)
            return
        
        for keyb in keywords :
            if type(keyb) is not str :
                print ("Initialize error : invalid keywordB. keywordB should be list of string")
                print (keywords)
                return
        
        if type(keywords) is list:
            self.keywordB = keywords
        else :
            print ("Warning! keywords should be list type : " + str(keywords))
    
    def isValid(self):
        if self.keywordA is not None and self.keywordA is not None and type(self.keywordA) is not list:
            return False
        
        if type(self.keywordB) is not list:
            return False
        
        for keya in self.keywordA :
            if type(keya) is not str :
                return False
        
        for keyb in self.keywordB :
            if type(keyb) is not str :
                return False
        
        if len(self.keywordB) == 0:
            return False
        
        if self.topN <= 0:
            return False
        
        return True
    
    def getKeywordB (self):
        """Getting the secondary keywords (Keyword B)
        
        :return: list of keyword B string
        
        >>> keywordB = query.getKeywordB()
        >>> print (keywordB)
        ["breast cancer","BRCA1"]
        """
        return self.keywordB
    
    def addKeywordtoB (self, keyword):
        """Adding a keyword to the secondary keyword list (Keyword B)
        
        :param keyword: the keyword to be added to the secondary keyword list
        
        >>> print (query.getKeywordB())
        ["breast cancer","BRCA1"]
        >>> query.addKeywordtoB("EGFR")
        >>> print (query.getKeywordB())
        ["breast cancer","BRCA1","EGFR"]
        """
        self.keywordB.append(keyword)
    
    def removeKeywordfromB(self, keyword):
        """Removing a keyword from the secondary keyword list (Keyword B)
        
        :param keyword: the keyword to be removed from the secondary keyword list
        
        >>> print (query.getKeywordB())
        ["breast cancer","BRCA1","EGFR"]
        >>> query.removeKeywordfromB("EGFR")
        >>> print (query.getKeywordB())
        ["breast cancer"]
        """
        self.keywordB.remove(keyword)
    
    def setTopN (self, n):
        """ Setting the number of results retrieved by query
        
        :param n: the number of results to be retrieved
        
        >>> query.setTopN(100)
        """
        self.topN = n
        
    def getTopN (self):
        """ Getting the number of results retrieved by query
        
        :return: the number of results to be retrieved
        
        >>> print (query.getTopN())
        100
        """
        return self.topN
    
    def makeQueryString(self, type):
        paramKeywordA = reduce(lambda x, y: x +" OR " + y ,  map(lambda x:"("+x+")", self.keywordA))
        paramKeywordB = reduce(lambda x, y: x +" OR " + y ,  map(lambda x:"("+x+")", self.keywordB))
        
        queryKeywords = paramKeywordB
        
        if paramKeywordA != "()" :
            queryKeywords = "(" + queryKeywords + ") AND (" + paramKeywordA + ")"
        
        import urllib.parse
        
        queryKeywords = "q=" + urllib.parse.quote(queryKeywords)
        
        otype = ""
        if type == "gene":
            otype = "8"
        elif type == "pathway":
            otype = "12"
        elif type == "disease":
            otype= "4"
        
        if otype == "":
            return "Invalid type! type can be [gene, pathway, disease]"
        
        strQuery = self.bossurl + "t=l&wt=xslt&tr=tmpl.xsl" + "&otype=" + otype + "&rows=" + str(self.topN) + "&" + queryKeywords
        
        return strQuery


def getRelevantBioEntities(bossQuery):
    """ Function for retrieval from BOSS
    
    :param bossQuery: BOSSQuery
    
    :return: parsed objects (dict-ENTITY_SET).
    
    * ENTITY_SET (dict): {"genes":[BIOENTITY] , "pathways":[BIOENTITY], "diseases":[BIOENTITY]}
    * BIOENTITY (dict): {"rank":int, "score":float, "numArticles":int, "abstracts":[str]}
    
    >>> bossQuery = BOSSQuery({"keywordA":"cancer", "keywordB":["breast cancer","BRCA1"], "topN":5})
    >>> relevantEntities = getRelevantBioEntities(bossQuery)
    """
    if not (type(bossQuery) is BOSSQuery):
        print ("query is invalid! please check your query object.")
        return {"genes":[], "pathways":[], "diseases":[]}
    
    if not bossQuery.isValid() :
        print ("Query object is invalid. Please check the query")
        print ("Query : ")
        print ("   keywordA: " + str(bossQuery.keywordA))
        print ("   keywordB: " + str(bossQuery.keywordB))
        print ("   topN: " + str(bossQuery.topN))
            
        return {"genes":[], "pathways":[], "diseases":[]}
    
    geneQuery = bossQuery.makeQueryString("gene")
    pathwayQuery = bossQuery.makeQueryString("pathway")
    diseaseQuery = bossQuery.makeQueryString("disease")
    
    import urllib.request
    
    geneUrl = urllib.request.urlopen(geneQuery)
    geneResultStr = geneUrl.read().decode('utf-8')
    geneResult = makeDataFromBossQueryResult(geneResultStr)
    
    pathwayUrl = urllib.request.urlopen(pathwayQuery)
    pathwayResultStr = pathwayUrl.read().decode('utf-8')
    pathwayResult = makeDataFromBossQueryResult(pathwayResultStr)

    diseaseUrl = urllib.request.urlopen(diseaseQuery)
    diseaseResultStr = diseaseUrl.read().decode('utf-8')
    diseaseResult = makeDataFromBossQueryResult(diseaseResultStr)
    
    return {"genes":geneResult, "pathways":pathwayResult, "diseases":diseaseResult}
    
def makeDataFromBossQueryResult(resultStr):
    lines = resultStr.split('\n')
    linesCnt = len(lines)
    
    resultDataArr = []
    curData = {"rank":0}
    for i in range(1, linesCnt) :
        line = lines[i]
        
        if line.startswith("@@@"):
            curData["abstracts"].append(line[3:].strip())
        else:
            if len(line.strip()) == 0 :
                continue
            
            if curData["rank"] != 0:
                resultDataArr.append(curData)
            
            dataResult = line.split(" | ")
            
            curData = {"rank":int(dataResult[0].strip()), "entityName":dataResult[1].strip(), "score":float(dataResult[2].strip()), "numArticles":int(dataResult[3].strip()), "abstracts":[]}
                
    resultDataArr.append(curData)
    
    return resultDataArr